module.exports = {
    HOST: "localhost",
    USER: "root",
    PASSWORD: "",
    DB: "node",
    PORT: "3306"
  };